# CozyPaws — full 36-shape Hyprland cursor set (pure vector)

A manually redrawn, fully editable **pure SVG** cursor set with cozy cream, pink flowers, paw motifs, warm brown outlines, and a small sleepy fluffy dog, inspired by the provided seasonal illustrations.

## Contents

- `svg/`: 36 pure vector cursor SVG files + 10 wait and 8 progress separate vector animation frames.
- `hyprcursor-source/`: editable official-format Hyprcursor source, manifest + `meta.hl` and SVGs.
- `CozyPaws/`: pre-packed Hyprcursor format (`manifest.hl` and 36 zipped `.hlc` shapes); packed following upstream `hyprcursor-util --create` file format. **This exact Hyprcursor package was assembled from the published format, not runtime-tested in a live Hyprland session.**
- `CozyPaws-XCursor/`: actual XCursor binary theme, validated by reloading each cursor with system libXcursor, including common legacy aliases and 32/48/64 size variants.
- `png_preview/`: raster previews, rendered from the pure SVGs. These aren't used as Hyprcursor theme assets.
- `preview_all_cream.png`, `preview_all_dark.png`: theme preview sheets.
- `install.sh`: copies both theme directories to user icon location.

## Install (existing Linux Hyprland environment)

Extract into any folder, then:

```bash
./install.sh
hyprctl setcursor CozyPaws 32
```

In Hyprland config (syntax depends on your current Hyprland version), set:

```ini
env = HYPRCURSOR_THEME,CozyPaws
env = HYPRCURSOR_SIZE,32
env = XCURSOR_THEME,CozyPaws-XCursor
env = XCURSOR_SIZE,32
```

Older applications and some GTK apps use XCursor. To set GTK's preference when available:

```bash
gsettings set org.gnome.desktop.interface cursor-theme CozyPaws-XCursor
```

To *independently compile the included editable source with the official utility*:

```bash
hyprcursor-util --create ./hyprcursor-source
```

## Accuracy & editability

SVGs have **no embedded PNGs**. All 36 named protocol shapes are present; partial extra compatibility aliases included. `wait` has 10 separate animated vector frames and `progress` has 8. For the rounded motif style, old eight initial pure-vector cursor designs were retained as-is, and the remaining shapes were custom authored to match.

Wayland cursor-shape protocol v2 (36 shapes) and Hyprcursor `meta.hl` convention formed the file-format basis.
