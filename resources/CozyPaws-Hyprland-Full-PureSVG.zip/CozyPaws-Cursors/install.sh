#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HOME/.local/share/icons"
cp -a "$ROOT/CozyPaws" "$HOME/.local/share/icons/"
cp -a "$ROOT/CozyPaws-XCursor" "$HOME/.local/share/icons/"
printf 'Installed CozyPaws and CozyPaws-XCursor.\n'
printf 'For this session: hyprctl setcursor CozyPaws 32\n'
printf 'For GTK/Xcursor, add XCURSOR_THEME=CozyPaws-XCursor and XCURSOR_SIZE=32 to your Hyprland config.\n'
